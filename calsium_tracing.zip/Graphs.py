import numpy as np

#Recursive algorithm to get groups of cells that pass the cut-off on similarity
#Adjust cutOff to change group sizes
def getMaxGroup(group, x, graph, value, cutOff = .5):
    if value < 0:
        return 0
    vals = []
    valMax = -1
    for y in range(len(graph[x])):
        if y == x:
            vals.append(-1)
        else:
            vals.append(graph[x][y] - cutOff)
    if all(0 >= x for x in vals): #If no groupings can potentially improve then abandon current recursive call
        return 0
    for y in range(len(vals)):
        if vals[y] > 0 and y not in group:
            invalid = []
            val = 0
            for element in group:
                if graph[element][y] - cutOff < 0:
                    invalid.append(element)
            if len(invalid) < len(group)/2:
                valOp = 0
                for element in invalid:
                    valOp += graph[x][element] - cutOff
                if valOp < vals[y]: #if new cells score higher than all replacements then replace, can replace none and just add a cell
                    group.append(y)
                    for element in invalid:
                        group.remove(element)
                val = getMaxGroup(group, y, graph, vals[y]/len(group))
                
            if val < valMax and y in group: #If recursive call give sub-optimal solution then discard
                group.remove(y)
            elif y in group:
                valMax = val
    return valMax
                
    
class Graph:
    def __init__(self, df):
        #load graph class with cell data
        self.df = df
    #Gather conditional probabilities based on current and next time slot    
    def create(self):
        
        #Small value to ensure to division by zero
        xS = .00000001
        
        #Graphs with shape (#cells,#cells)
        self.graph = [[0 for y in range( len(self.df.columns))] for x in range( len(self.df.columns))]
        #self.graph = np.zeros([len(self.df.columns), len(self.df.columns)])
        #self.graphNext = np.zeros([len(self.df.columns), len(self.df.columns)])
        self.graphNext = [[0 for y in range( len(self.df.columns))] for x in range( len(self.df.columns))]
        past = []
        for index, row in self.df.iterrows():
            #Get list of active cells at current timestamp
            active = [x for x in range(len(row)) if row[x] == 1]
            #ignore first iteration to allow for condition probabilities based on following values
            #This part can be alterned if the change between individual timestamps is minuscule 
            if index == 0:
                past = active
                continue

            for x in active:
                for y in active:
                    #One more connection from x to y found
                    self.graph[x][y] +=1
            for x in past:
                for y in active:
                    #One more connection from x past to y current found
                    self.graphNext[x][y] +=1 
            #print(self.graph)
            past = active

        #Set the range of all values to probability
        for x in range(len(self.df.columns)):
            val = self.graph[x][x] + xS
            valNext = self.graphNext[x][x] + xS
            for y in range(len(self.df.columns)):
                self.graph[x][y] /= val
                self.graphNext[x][y] /= valNext
    
    #If interested in probabilities over a range for how often cells appear
    def probShift(self, start, end):
        return np.sum(np.array(self.df.iloc[start:end]), 0)/len(self.df.iloc[start:end])
    
    #Returns list of columns names (cells)
    def mmap(self):
        return self.df.columns.tolist()

    #Find common elements between two groupings
    def countCluster(self, group1, group2):
        group1_as_set = set(group1)
        intersection = group1_as_set.intersection(group2)
        return len(intersection)

    #Group together cells based on 
    def grouping(self, graph):
        #grouping = graph.copy()
        grouping = []
        for x in range(len(graph)):
            memGroups = [x]
            group = getMaxGroup(memGroups, x, graph, 0) 
            #grouping[x] = [y for y in range(len(graph[x])) if graph[x][y] > .5]
            grouping.append(memGroups)
        return grouping

    #Group together groups with high level of similarity, adjust cutOff to change group sizes
    def reduceGroups(self, groups, cutOff = .50):
        i = 0
        while groups[i] == []:
            i +=1
        reducedGroups = [groups[i]]
        for x in range(i+1,len(groups)):
            unique = True
            for y in reducedGroups:
                count = self.countCluster(y, groups[x])
                if count/(sum([len(groups[x]), len(y)+.000001])-count) >= cutOff:
                    y.extend(groups[x])
                    unique = False
                if count == min([len(groups[x]), len(y)]):
                    unique = False
            if unique:
                reducedGroups.append(groups[x])
        result = []
        for y in reducedGroups:
            result.append(list(set(y)))
        return result
    
    #Convert from numerical to cell names
    def toCells(self, reducedGroups, cells):
        for group in reducedGroups:
            for count,x in enumerate(group):
                group[count] = cells[x]
        return reducedGroups

    #Convert from cell to numberical
    def toArrayDic(self, cells):
        myDic = {}
        for x, element in enumerate(cells):
            myDic[element] = x
        return myDic
