import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
import pandas as pd
import numpy as np
import umap
import umap.plot
from sklearn import preprocessing

#take in cell data and normalize and simplify by default
def preprocessed_df(path, simplify = True):
    
    #Read in csv
    df = pd.read_csv(path)
    
    #get cells to keep
    toAccept = df.columns[df.iloc[0] == " accepted"]
    
    #Reread csv for accepted cells, this part can be improved
    df = pd.read_csv(path, usecols =[i for i in toAccept])
    
    #drop classifying row
    df = df.iloc[1:]
    
    #convert cell data to numeric
    df = df.apply(pd.to_numeric)
    
    # normalize all cells
    df = df.apply(lambda x: (x - x.min()) / (x.max() - x.min()), axis = 0)
    
    ###Alternative normalizing
    #df = np.array(df)
    #scaler = preprocessing.StandardScaler().fit(df)
    #df_scaled = scaler.transform(df)
    ###
    
    ###Many ways to preprocess data including a sotfmax approach.
    #Used method was choosen as it gave good results.
    ###
    
    #If choosed then convert to binary with a choosen limit for what is
    #considered an active cell vs deactive
    if simplify:
        df = df.applymap(lambda x: 1 if x >= .6 else 0)
    return df


#Following is to get an idea of clusters
#Can be played with and wouldn't give any spatial information
def reduce_dimensions(df):
    # keep high dimensional structure in low dimension
    _umap = umap.UMAP(n_neighbors=3,
                     n_components=5,
                     min_dist = 0.65,
                     metric='jaccard').fit(df)
    umap_embeddings = _umap.transform(df)
    
    return _umap, umap_embeddings

def dbscan(embeddings, eps=3, min_samples=2):
    cluster = DBSCAN(eps=eps, min_samples=min_samples).fit(embeddings)
    return cluster.labels_

def show_prediction(df, clusters):
    # Prepare data
    bert_umap = umap.UMAP(n_neighbors=10,
                 n_components=2,
                 min_dist = 0.0,
                 metric='braycurtis').fit_transform(df)
    result = pd.DataFrame(bert_umap, columns=['x', 'y'])
    
    result['labels'] = clusters   # grab labels from clustering

    # Visualize clusters
    fig, ax = plt.subplots(figsize=(20, 10))
    outliers = result.loc[result.labels == -1, :]
    clustered = result.loc[result.labels != -1, :]
    plt.scatter(outliers.x, outliers.y, color='#BDBDBD', s=100)
    plt.scatter(clustered.x, clustered.y, c=clustered.labels, s=100, cmap='viridis')

    plt.show()
    
def relu(x):
    result = []
    for i in x:
        if i >= 0:
            result.append(i)
        else:
            result.append(i/10)
    return result
